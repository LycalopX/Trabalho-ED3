#ifndef F3_H
#define F3_H

/**
 * @brief Lê os registros do arquivo de dados e exibe na tela os que não estão removidos.
 * @param nomeArquivo O nome do arquivo de dados binário a ser lido.
 */
void funcionalidade3(char *nomeArquivo);

#endif
